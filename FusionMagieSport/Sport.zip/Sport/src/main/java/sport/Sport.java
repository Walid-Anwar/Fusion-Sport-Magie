package sport;

public class Sport
{
    // variables d'instance - remplacez l'exemple qui suit par le vôtre
    private double technicite=0;
    private double enthousiame=0;

    /**
     * Constructeur d'objets de classe Sport
     */
    public Sport()
    {
        technicite= 0.0;
        enthousiame= 0.0;
        
    }

    public double scoreTotal(double technicite, double enthousiame)
    {
        this.technicite = this.technicite;
        this.enthousiame = enthousiame;
        
        double moyenne = (technicite + enthousiame) / 2;
        
        return moyenne;
    }
}
