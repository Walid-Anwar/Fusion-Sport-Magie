package sport;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class SportTest
{
    protected double fValeur1;
    protected double fValeur2;

    public SportTest()
    {
    }
    @BeforeEach
    public void setUp() // throws java.lang.Exception
    {
        // Initialisez ici vos engagements
        fValeur1= 2.0;
        fValeur2= 3.0;
    }
    @AfterEach
    public void tearDown() // throws java.lang.Exception
    {
        //Libérez ici les ressources engagées par setUp()
    }

    @Test
    public void testScoreTotal()
    {
        Sport volley = new Sport();
        assertEquals(6, volley.scoreTotal(6, 6), 0.1);
    }
}



