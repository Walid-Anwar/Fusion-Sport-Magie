import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import sport.Sport;

import static org.junit.jupiter.api.Assertions.assertEquals;
public class sportStepdefs {
    private Sport volley;
    private double result;
    @Given(value="^a Sport Volley$")
    public void set_it(){
        this.volley = new Sport();
    };
    @When(value="^i evaluate it$")
    public void wait_it(){
        this.result = this.volley.scoreTotal(6,6);
    };
    @Then(value="^I get a result$")
    public void check_it(){
        assertEquals(6, this.result, 0.1);
    };
}
